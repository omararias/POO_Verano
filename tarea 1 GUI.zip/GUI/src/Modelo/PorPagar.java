package Modelo;

/**
 *
 * @author carlo
 */
public interface PorPagar {

    double obtenerMontoPago();
}
