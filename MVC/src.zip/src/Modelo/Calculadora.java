/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.CtrlCalculadora;
import javax.swing.JOptionPane;

/**
 *
 * @author juan.ucan
 */
public class Calculadora {
    private CtrlCalculadora unCtrlCalculadora;

    public void setUnCtrlCalculadora(CtrlCalculadora unCtrlCalculadora) {
        this.unCtrlCalculadora = unCtrlCalculadora;
    }
    
    public String dividir(String numero1, String numero2){
        String resultado ="";    
        
        try{
            int num1 = Integer.parseInt(numero1); //punto de lanzamiento
            int num2 = Integer.parseInt(numero2);  //punto de lanzamiento
            resultado = "" + num1/num2; //punto de lanzamiento
        }
        catch(ArithmeticException exep1){
            //JOptionPane.showMessageDialog(parentComponent, "No se puede dividi entre cero");
            resultado = "No se puede dividi entre cero";            
        }
        catch(NumberFormatException excep2){
            resultado = "Los datos capturados debe ser números enteros";
        }
        
        return resultado;
    }
}
